import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';

@Component({
  selector: 'app-pressure-sensor',
  templateUrl: './pressure-sensor.component.html',
  styleUrls: ['./pressure-sensor.component.scss']
})
export class PressureSensorComponent extends dia.Element {
  defaults() {
    return {
      ...super.defaults, // Call super.defaults() to inherit base class defaults
      type: '',
      size: {
        width: 100,
        height: 100,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        circle: {
          cx: 50,
          cy: 50,
          r: 40,
          stroke: 'black',
          strokeWidth: 3,
          fill: '#f0f0f0',
        },
        text: {
          x: '50%',
          y: '50%',
          fontFamily: 'Arial',
          fontSize: 12,
          fill: 'black',
          textAnchor: 'middle',
          dominantBaseline: 'middle',
        },
        needle: {
          stroke: 'red',
          strokeWidth: 2,
          fill: 'none',
        },
        label: {
          x: '50%',
          y: '90%',
          fontFamily: 'Arial',
          fontSize: 10,
          fill: 'black',
          textAnchor: 'middle',
        },
        path: {
          stroke: 'black',
          strokeWidth: 2,
          fill: 'none',
        },
      },
      ports: {
        groups: {
          default: {
            position: {
              name: 'absolute',
              args: {
                x: '50%',
                y: '50%',
              },
            },
            size: { width: 0, height: 0 },
            attrs: {},
          },
        },
        items: [
          {
            id: 'port',
            group: 'default',
            z: 0,
          },
        ],
      },
    };
  }

  preinitialize() {
    this.markup = `
<svg height="100" width="100" xmlns="http://www.w3.org/2000/svg">
  <!-- Draw the outer circle -->
  <circle class="circle" />
  <!-- Draw the needle -->
  <line class="needle" x1="50" y1="50" x2="50" y2="20" />
  <!-- Draw the text in the center -->
  <text class="text">
    P
  </text>
  <!-- Draw the label below -->
  <text class="label">
    Pressure
  </text>
</svg>
    `;
    // Adding click event listener
    this.on('element:click', this.onClick.bind(this));
  }

  onClick() {
    console.log('Pressure sensor clicked');
  }
}


