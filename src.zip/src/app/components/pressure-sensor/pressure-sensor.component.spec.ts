import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PressureSensorComponent } from './pressure-sensor.component';

describe('PressureSensorComponent', () => {
  let component: PressureSensorComponent;
  let fixture: ComponentFixture<PressureSensorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PressureSensorComponent]
    });
    fixture = TestBed.createComponent(PressureSensorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
