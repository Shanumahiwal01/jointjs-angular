import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';
import { LIQUID_COLOR } from 'src/app/model/constant';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.scss']
})
export class PipeComponent extends dia.Link {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'Pipe',
      z: -1,
      router: { name: 'rightAngle' },
      flow: 1,
      attrs: {
        liquid: {
          connection: true,
          stroke: LIQUID_COLOR,
          strokeWidth: .5,
          strokeLinejoin: 'round',
          strokeLinecap: 'square',
          strokeDasharray: '.1,.2',
        },
        line: {
          connection: true,
          stroke: LIQUID_COLOR, //'#eee',
          strokeWidth: 1,
          strokeLinejoin: 'round',
          strokeLinecap: 'round',
        },
        outline: {
          connection: true,
          stroke: '#444',
          strokeWidth: .16,
          strokeLinejoin: 'round',
          strokeLinecap: 'round',
        },
      },
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="outline" fill="none"/>
            <path @selector="line" fill="none"/>
            <path @selector="liquid" fill="none"/>
        `;

//        console.log(this.markup);
  }
}

