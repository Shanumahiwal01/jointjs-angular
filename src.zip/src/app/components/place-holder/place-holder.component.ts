import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';

@Component({
  selector: 'app-place-holder',
  templateUrl: './place-holder.component.html',
  styleUrls: ['./place-holder.component.scss']
})
export class PlaceHolderComponent extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: "Placeholder",
      position: { x: 10, y: 10 },
      attrs: {
        root: {
          style: "cursor:default"
        },
        body: {
          class: "jj-placeholder-body",
          fill: "transparent",
          x: 0,
          y: 0,
          width: "calc(w)",
          height: "calc(h)"
        },
        label: {
          class: "jj-placeholder-label",
          fontSize: 14,
          fontFamily: "sans-serif",
          textVerticalAnchor: "middle",
          textAnchor: "middle",
          x: "calc(w/2)",
          y: "calc(h/2)"
        }
      }
    };
  }

  static isPlaceholder(element: any) {
    return element.get("type") === "Placeholder";
  }

  preinitialize() {
    this.markup = [
      {
        tagName: "rect",
        selector: "body"
      },
      {
        tagName: "text",
        selector: "label"
      }
    ];
  }
}

