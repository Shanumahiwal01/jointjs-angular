import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlValveComponent } from './control-valve.component';

describe('ControlValveComponent', () => {
  let component: ControlValveComponent;
  let fixture: ComponentFixture<ControlValveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ControlValveComponent]
    });
    fixture = TestBed.createComponent(ControlValveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
