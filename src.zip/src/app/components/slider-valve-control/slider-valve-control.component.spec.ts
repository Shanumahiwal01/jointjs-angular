import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SliderValveControlComponent } from './slider-valve-control.component';

describe('SliderValveControlComponent', () => {
  let component: SliderValveControlComponent;
  let fixture: ComponentFixture<SliderValveControlComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SliderValveControlComponent]
    });
    fixture = TestBed.createComponent(SliderValveControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
