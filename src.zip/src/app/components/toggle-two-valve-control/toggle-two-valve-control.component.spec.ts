import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleTwoValveControlComponent } from './toggle-two-valve-control.component';

describe('ToggleTwoValveControlComponent', () => {
  let component: ToggleTwoValveControlComponent;
  let fixture: ComponentFixture<ToggleTwoValveControlComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ToggleTwoValveControlComponent]
    });
    fixture = TestBed.createComponent(ToggleTwoValveControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
