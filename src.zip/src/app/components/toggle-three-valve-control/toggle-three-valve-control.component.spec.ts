import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleThreeValveControlComponent } from './toggle-three-valve-control.component';

describe('ToggleThreeValveControlComponent', () => {
  let component: ToggleThreeValveControlComponent;
  let fixture: ComponentFixture<ToggleThreeValveControlComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ToggleThreeValveControlComponent]
    });
    fixture = TestBed.createComponent(ToggleThreeValveControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
