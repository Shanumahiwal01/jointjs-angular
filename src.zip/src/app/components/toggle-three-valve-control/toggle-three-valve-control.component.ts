import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';
import { LIQUID_COLOR, LIQUID_COLOR_OFF, THREEOWAY_VALVE_VERTICAL, THREEWAY_VALVE_HORIZONTAL } from 'src/app/model/constant';

@Component({
  selector: 'app-toggle-three-valve-control',
  templateUrl: './toggle-three-valve-control.component.html',
  styleUrls: ['./toggle-three-valve-control.component.scss']
})
export class ToggleThreeValveControlComponent extends dia.HighlighterView.extend({
      UPDATE_ATTRIBUTES: ["open"],
      children: util.svg/* xml */ `
            <foreignObject width="100" height="50">
                <div class="jj-switch" xmlns="http://www.w3.org/1999/xhtml">
                    <div @selector="label" class="jj-switch-label" style=""></div>
                    <button @selector="buttonOn" class="jj-switch-on">open</button>
                    <button @selector="buttonOff" class="jj-switch-off">close</button>
                </div>
            </foreignObject>
        `,
      events: {
        "click button": "onButtonClick"
      },
      highlight: function (cellView: any) {
        this.renderChildren();
        const { model } = cellView;
        const { el, childNodes } = this;
        const size = model.size();
        var isOpen = model.get("open");
    //    console.log(isOpen);
        el.setAttribute(
          "transform",
          `translate(${size.width / 2 - 50}, ${size.height + 10})`
        );
        childNodes.buttonOn.disabled = isOpen;
        childNodes.buttonOff.disabled = !isOpen;
        childNodes.label.textContent = model.attr("label/text");
      },
      onButtonClick: function (evt: any) {
        var { model } = this.cellView;
        const isOpen = model.get("open");
        model.collection.models.forEach((e: any) => {
          if(e.attributes["type"] == "Pipe"){
            if(e.attributes["target"].id == model.id){
              e.attr("line").stroke = isOpen ? LIQUID_COLOR_OFF : LIQUID_COLOR;
            }
        }
    
        //console.log(e.attributes);
        //console.log(e);
        
        if(e.attributes["type"] == "Triangle"){
          if(e.attributes["id"] == model.id){
            e.attr("legs").d = isOpen ? THREEOWAY_VALVE_VERTICAL : THREEWAY_VALVE_HORIZONTAL;
            // e.attr("legs").stroke = isOpen ? LIQUID_COLOR_OFF : LIQUID_COLOR;
            console.log(e.attr("legs"));
            //e.attributes["rotate"] = 90
          }
      }
    
        });
    
        //const { el, childNodes } = this;
    
        // const el = model as dia.Element
        // if(isOpen)
        //   el.attributes.attrs?.legs?.d?.replace(TWOWAY_VALVE_HORIZONTAL, TWOWAY_VALVE_VERTICAL);
        // else
        //   el.attributes.attrs?.legs?.d?.replace(TWOWAY_VALVE_VERTICAL, TWOWAY_VALVE_HORIZONTAL);
    
        // console.log(el.attributes.attrs?.legs?.d);
        
        //  (isOpen ?
        //    {
        //     fill: 'lightblue',
        //     stroke: 'lightblue',
        //     strokeWidth: 2,
        //     strokeLinecap: 'butt',
        //     d: TWOWAY_VALVE_VERTICAL
        //   }
        //    : {
        //     fill: 'lightblue',
        //     stroke: 'lightblue',
        //     strokeWidth: 2,
        //     strokeLinecap: 'butt',
        //     d: TWOWAY_VALVE_HORIZONTAL
        //   }));
    
        model.set("open", !isOpen);
        alert("Id: " + model.id + "; Name: " + model.attr("label/text") + "; New Status: " + (isOpen ? "Close" : "Open") )
      }
  }){
      
  }
  