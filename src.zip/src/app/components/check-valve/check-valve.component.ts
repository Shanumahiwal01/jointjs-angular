import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';

@Component({
  selector: 'app-check-valve',
  templateUrl: './check-valve.component.html',
  styleUrls: ['./check-valve.component.scss']
})
export class CheckValveComponent extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: "CheckValve",
      size: {
        width: 100, // Adjust width and height as per the new SVG dimensions
        height: 100
      },
      attrs: {
        root: {
          magnetSelector: "body"
        },
        body: {
          // Attributes for the polygon and circle
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        polygon: {
          points: "35,36 10,50 35,65",
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        circle: {
          cx: 26,
          cy: 50,
          r: 7,
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        label: {
          text: "CheckValve",
          textAnchor: "middle",
          textVerticalAnchor: "bottom",
          x: "30",
          y: "calc(h + 12)",
          fontSize: "14",
          fontFamily: "sans-serif",
          fill: "#350100"
        }
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
      <polygon @selector="polygon" points="40,30 -1,55 40,85" fill="white" stroke="purple" stroke-width="2" />
      <circle @selector="circle" cx="25" cy="55" r="13" fill="white" stroke="purple" stroke-width="2" />
      <text @selector="label" />
    `;
  }
}


