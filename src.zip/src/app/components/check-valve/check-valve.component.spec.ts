import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckValveComponent } from './check-valve.component';

describe('CheckValveComponent', () => {
  let component: CheckValveComponent;
  let fixture: ComponentFixture<CheckValveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CheckValveComponent]
    });
    fixture = TestBed.createComponent(CheckValveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
