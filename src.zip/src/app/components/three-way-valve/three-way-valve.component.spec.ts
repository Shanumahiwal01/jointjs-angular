import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeWayValveComponent } from './three-way-valve.component';

describe('ThreeWayValveComponent', () => {
  let component: ThreeWayValveComponent;
  let fixture: ComponentFixture<ThreeWayValveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ThreeWayValveComponent]
    });
    fixture = TestBed.createComponent(ThreeWayValveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
