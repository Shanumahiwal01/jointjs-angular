import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';

@Component({
  selector: 'app-three-way-valve',
  templateUrl: './three-way-valve.component.html',
  styleUrls: ['./three-way-valve.component.scss']
})
export class ThreeWayValveComponent extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'Triangle',
      size: {
        width: 5,
        height: 5,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        legs: {
          fill: 'turquoise',
          stroke: 'turquoise',
          strokeWidth: 2,
          strokeLinecap: 'butt',
          d: 'M 20,20 L 35,10 L 35,30 Z M 25,40 L 8,40 L 18,24 Z M 0,10 L 0,30 L 16,20 Z', 
          //d: 'M 45 45 L 33 33 L 33 58 Z M 58 58 L 58 33 L 45 45 Z'
        },
        body: {
          fill: '#ffffff',
          stroke: '#cad8e3',
          strokeWidth: 1,
          d: 'M 0 calc(0.5*h) calc(0.5*h) 0 H calc(w) V calc(h) H calc(0.5*h) Z',
        },
        // top: {
        //   x: 2,
        //   y: 25,
        //   width: 'calc(w)',
        //   height: 1,
        //   fill: 'none',
        //   stroke: 'gray',
        //   strokeWidth: 1,
        // },
        label: {
          text: 'ThreeWayValve',
          fontSize: 14,
          fontFamily: 'sans-serif',
          //fontWeight: 'bold',
          fill: "cad8e3",
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          x: 'calc(w / 2)',
          y: 'calc(h / 1)',
        },
      },
      events: {
        "click button": "onButtonClick"
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="legs"/>
            <rect @selector="body"/>
            <rect @selector="top"/>
            <text @selector="label" />
        `;
    // Adding click event listener for rotation
    this.on('element:click', this.rotate);
  }
  get rotation() {
    return this.get('rotation') || 0;
  }
  set rotation(angle: number) {
    this.set('rotation', angle);
    //this.updateRotation();
  }

  get level() {
    return this.get('level') || 0;
  }

  set level(level) {
    const newLevel = Math.max(0, Math.min(100, level));
    this.set('level', newLevel);
  }
}
