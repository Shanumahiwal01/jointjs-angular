import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LiquidTankComponent } from './liquid-tank.component';

describe('LiquidTankComponent', () => {
  let component: LiquidTankComponent;
  let fixture: ComponentFixture<LiquidTankComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LiquidTankComponent]
    });
    fixture = TestBed.createComponent(LiquidTankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
