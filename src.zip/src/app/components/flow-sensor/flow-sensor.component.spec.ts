import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowSensorComponent } from './flow-sensor.component';

describe('FlowSensorComponent', () => {
  let component: FlowSensorComponent;
  let fixture: ComponentFixture<FlowSensorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FlowSensorComponent]
    });
    fixture = TestBed.createComponent(FlowSensorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
