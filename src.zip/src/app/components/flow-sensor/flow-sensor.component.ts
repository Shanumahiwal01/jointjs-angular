import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';

@Component({
  selector: 'app-flow-sensor',
  templateUrl: './flow-sensor.component.html',
  styleUrls: ['./flow-sensor.component.scss']
})
export class FlowSensorComponent extends dia.Element {
  defaults(): any {
    return {
      //...super.defaults(), // Call super.defaults() if available and correct
      type: '',
      size: {
        width: 100,
        height: 100,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        legs: {
          // Example styles for the path element with selector "legs"
          stroke: 'black',
          strokeWidth: 2,
          fill: 'none',
        },
        body: {
          // Example styles for the rect element with selector "body"
          x: 10,
          y: 10,
          width: 80,
          height: 40,
          stroke: 'black',
          strokeWidth: 2,
          fill: '#4CBB17',
        },
        top: {
          // Example styles for the rect element with selector "top"
          x: 10,
          y: 60,
          width: 80,
          height: 20,
          stroke: 'black',
          strokeWidth: 2,
          fill: '#2E8B57',
        },
        label: {
          // Example styles for the text element with selector "label"
          x: '50%',
          y: '50%',
          fontFamily: 'Arial',
          fontSize: 8,
          fill: 'white',
          textAnchor: 'middle',
          dominantBaseline: 'middle',
        },
      },
      ports: {
        groups: {
          default: {
            position: {
              name: 'absolute',
              args: {
                x: '50%',
                y: '50%',
              },
            },
            size: { width: 0, height: 0 },
            attrs: {},
          },
        },
        items: [
          {
            id: 'port',
            group: 'default',
            z: 0,
          },
        ],
      },
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
<svg height="100" width="100" xmlns="http://www.w3.org/2000/svg">
  <!-- Define arrowhead marker -->
  <defs>
    <marker id="arrowhead" markerWidth="5" markerHeight="10" refX="0" refY="3" orient="auto" fill="black">
      <path d="M-1,0 L0,6 L5,3 z"/>
    </marker>
  </defs>
  <!-- Draw the path with selector "legs" -->
  <path @selector="legs" d="M75,50 L90,50 L90,70" />
  <!-- Draw the rectangle with selector "body" -->
  <rect @selector="body" />
  <!-- Draw the rectangle with selector "top" -->
  <rect @selector="top" />
  <!-- Draw the text with selector "label" -->
  <text @selector="label">
    F
  </text>
</svg>
    `;
    // Adding click event listener
    this.on('element:click', this.onClick);
  }

  onClick() {
    console.log('Element clicked');
  }
}
