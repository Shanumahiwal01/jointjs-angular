import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HandValveComponent } from './hand-valve.component';

describe('HandValveComponent', () => {
  let component: HandValveComponent;
  let fixture: ComponentFixture<HandValveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HandValveComponent]
    });
    fixture = TestBed.createComponent(HandValveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
