import { Component } from '@angular/core';
import { dia, util } from '@joint/plus';
import { OPEN_FLAG } from 'src/app/model/constant';

@Component({
  selector: 'app-control-valve-view',
  templateUrl: './control-valve-view.component.html',
  styleUrls: ['./control-valve-view.component.scss']
})
export class ControlValveViewComponent extends dia.ElementView {
  defaults(): any {
    return {
      presentationAttributes: dia.ElementView.addPresentationAttributes({
        open: [OPEN_FLAG]
      }),
    
      initFlag: [dia.ElementView.Flags.RENDER, OPEN_FLAG],
    
      framePadding: 6,
    
      liquidAnimation: null,
    
      confirmUpdate : function(...args : any) {
        let flags = dia.ElementView.prototype.confirmUpdate.call(this,1,[...args]);
        //this.animateLiquid();
        if (this.hasFlag(flags, OPEN_FLAG)) {
          this.updateCover();
          flags = this.removeFlag(flags, OPEN_FLAG);
        }
        return flags;
      },
    
      updateCover: function () {
        const { model } = this;
        const opening = Math.max(0, Math.min(1, model.get("open") || 0));
        const [coverEl] = this.findBySelector("cover");
        const [coverFrameEl] = this.findBySelector("coverFrame");
        const frameWidth =
          Number(coverFrameEl.getAttribute("width")) - this.framePadding;
        const width = Math.round(frameWidth * (1 - opening));
        coverEl.animate(
          {
            width: [`${width}px`]
          },
          {
            fill: "forwards",
            duration: 200
          }
        );
      },
    
      animateLiquid : function() {
        if (this.liquidAnimation) return;
        console.log(this.findBySelector("liquid"));
        //if(this.findBySelector("liquid").length == 0) return;
        const [liquidEl] = this.findBySelector("liquid") as [SVGAElement];
        console.log([liquidEl])
        this.liquidAnimation = liquidEl.animate(
          {
            // 24 matches the length of the liquid path
            strokeDashoffset: [0, 24]
          },
          {
            fill: "forwards",
            iterations: Infinity,
            duration: 3000
          }
        );
      }
    }
  }
}
