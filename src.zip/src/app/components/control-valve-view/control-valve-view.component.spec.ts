import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlValveViewComponent } from './control-valve-view.component';

describe('ControlValveViewComponent', () => {
  let component: ControlValveViewComponent;
  let fixture: ComponentFixture<ControlValveViewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ControlValveViewComponent]
    });
    fixture = TestBed.createComponent(ControlValveViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
