import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwoWayValveComponent } from './two-way-valve.component';

describe('TwoWayValveComponent', () => {
  let component: TwoWayValveComponent;
  let fixture: ComponentFixture<TwoWayValveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TwoWayValveComponent]
    });
    fixture = TestBed.createComponent(TwoWayValveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
