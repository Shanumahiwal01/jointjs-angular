import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header-view',
  templateUrl: './header-view.component.html',
  styleUrls: ['./header-view.component.scss']
})
export class HeaderViewComponent implements OnInit {

  userName: string = '';

  logoutForm: FormGroup = <FormGroup>{}
  @ViewChild('form', { static: true }) formatElement: NgForm = <NgForm>{};

  constructor(
    private fb: FormBuilder,
  private router: Router 
  ){
    this.userName = localStorage.getItem('userName') as string;
  }
  ngOnInit(): void {
    this.userName = localStorage.getItem('userName') as string;
//    console.log(this.userName);
    this.logoutForm = this.fb.group({
    })
  }


  logout(event: any){
      localStorage.setItem('userName', '');
      this.router.navigate(['login']);
      
  }

}
