import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToggleValveControlComponent } from './toggle-valve-control.component';

describe('ToggleValveControlComponent', () => {
  let component: ToggleValveControlComponent;
  let fixture: ComponentFixture<ToggleValveControlComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ToggleValveControlComponent]
    });
    fixture = TestBed.createComponent(ToggleValveControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
