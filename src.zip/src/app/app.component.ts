import {
  AfterViewInit,
  OnInit,
  Component,
  ElementRef,
  ViewChild,
} from '@angular/core';
//import { dia, ui, shapes, util, layout, highlighters, elementTools } from '@joint/plus';
//import { LiquidTank, TwoWayValve,Zone, Pipe, HandValve,CheckValve, ControlValve, Placeholder, StencilGroup, ControlValveView, PipeView, SliderValveControl, ToggleValveControl, ToggleTwoValveControl, ThreeWayValve } from './model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterViewInit {

//   @ViewChild('canvas') canvas: ElementRef;
//   @ViewChild('stencil') stencil: ElementRef;

//   private graph: dia.Graph;
//   private paper: dia.Paper;
//   private scroller: ui.PaperScroller;
//   private stencilSide: ui.Stencil;
//   //private graphLeft: dia.Graph;
//   private paperLeft: dia.Paper;
  
//   private connectList: dia.Element[] = [];
//   //private elementPipeList: any[] = [];

//   private namespace = {
//     ...shapes,
//     LiquidTank,
//     TwoWayValve,
//     ThreeWayValve,
//     Zone,
//     HandValve,
//     CheckValve,
//     ControlValve,
//     Pipe,
//     //PipeView,
//     //ControlValveView,
//   };


  public ngOnInit(): void {
    
  }
  
//     //const graphLeft = this.graphLeft = new dia.Graph({}, { cellNamespace: this.namespace });
    
  
//     const graph = this.graph = new dia.Graph({}, { cellNamespace: this.namespace });
//     this.buildLayoutLeft(graph);
//     this.buildLayout(graph);


//     this.buildComponents(graph);

//     this.buildSensilActions(graph);
//   }

// private buildSensilActions(
// graph: dia.Graph<dia.Graph.Attributes, dia.ModelSetOptions>
// )
// {
// this.stencilSide.on("element:drag", (dragView, evt, cloneArea, validArea) => {
  
// });

// this.stencilSide.on("element:dragend", (dragView, evt, context) => {
  


//   var el = dragView.model.clone() as dia.Cell;


//   //console.log(el);



//   var elements = this.GetGraphElements(el.attributes["type"]);
  
//   var len = elements.length;

//   //console.log(len);
//   var attrs = el.attributes.attrs as dia.Cell.Selectors;

//   attrs.label = {
//       fill: "#350100",
//       fontFamily: "sans-serif",
//       fontSize: 14,
//       text: attrs.label?.text + " " + (len + 1),
//       textAnchor: "middle",
//       textVerticalAnchor: "top",
//       x: "calc(w/2)",
//       y:"calc(h + 10)"
//     };
  
//   //console.log(attrs.label);

//   //?.label?.text =  el.attributes.attrs?.label?.text  + " " + len;
    
//   el.attributes.position = { x: context.x, y: context.y };
//   //el.re();
//   //console.log(el);
//   el.addTo(this.graph);

//   //console.log(this.stencil)
//   //el = el;
//   //(dragView.model as dia.Cell).remove();
  
//   //  var tempElements = elements.filter(item => item.attributes.attrs?.label?.text == dragView.model.attributes.attrs.label.text);
//   // tempElements.forEach( item => item.remove())
  
//  // var tempElements = this.graph.attributes.cells?.models;

//   //console.log(el);
//   //console.log(this.graph.getElements());
//   //console.log(tempElements);
  
  
  
//  // console.log(dragView);
  
//   // if(el.attr("label/text") == "Valve 1")
//   //   {
//   //     //console.log(dragView);
//   //     dragView.el.remove(this.graph);
//   //     //return;
//   //   }
   
  

//   // Create all controls and add them to the graph
//  //this.addControls(el);
//  //this.paper.trigger("blank:pointerdown");
 
//  this.addControlsToPaper(this.paper);

// });

// this.paper.on("element:pointerclick", (elementView) => {

//   //console.log(elementView.model);
//   //this.ConnectByPipe(elementView.model);

//   this.paper.removeTools();
  
//   //console.log(this.connectList);  


//   if(this.connectList.findIndex(item => item.graph == null) > -1)
//     this.connectList = [];

  
// const toolsView = new dia.ToolsView({
//   tools: [
//     new elementTools.Boundary({
//       useModelGeometry: true
//     }),
//     // new elementTools.Connect({
//     //   useModelGeometry: true,
//     //   x: "calc(w + 10)",
//     //   y: "calc(h / 2)"
//     // }),
//     new elementTools.Remove({
//       useModelGeometry: true,
//       x: -10,
//       y: -10
//     })
//   ]
// });
// elementView.addTools(toolsView);

// if(elementView.mountTools())
//   this.ConnectByPipe(elementView.model);

// //if(elementView.showTools())

// });

// this.paper.on("blank:pointerdown", () => {
// this.paper.removeTools();
// //this.connectList.slice(0, this.connectList.length);
// this.connectList = [];
// //this.addControlsToPaper(this.paper);

// //console.log("blank:pointerdown")

// });

// }


// private addControlsToPaper(paper: any) {
// const graph =  paper.model;
// var removeItems = [];
// graph.getElements().forEach((cell: any) => {
//   //console.log(cell);

//   var text = cell.attr("label/text");
//   if( text == "Valve" || text == "CTRL Valve"|| text == "Tank" || text == "Zone")
//     {
//       //console.log(dragView);
//       cell.remove(this.graph);
//       //return;
//     }
   

//   switch (cell.get("type")) {
//     case "ControlValve":
//       SliderValveControl.add(cell.findView(paper), "root", "slider", {
//         name: cell.attr("label/text")
//       });
//       break;
//     case "HandValve":
//       ToggleValveControl.add(cell.findView(paper), "root", "button");
//       break;  
//     case "Triangle":
//       ToggleTwoValveControl.add(cell.findView(paper), "root", "button");
      
//       break;
//     // case "Pump":
//     //   PumpControl.add(cell.findView(paper), "root", "selection");
//     //   break;
//   }
// });

// }


// private addControls(cell: dia.Element) {

// //console.log(cell);
//   switch (cell.get("type")) {
//     case "ControlValve":
//       SliderValveControl.add(cell.findView(this.paper), "root", "slider", {
//         name: cell.attr("label/text")
//       });
//       break;
//     case "HandValve":
//       ToggleValveControl.add(cell.findView(this.paper), "root", "button");
//       break;
//     // case "Pump":
//     //   PumpControl.add(cell.findView(paper), "root", "selection");
//     //   break;
//   }
// }



//   private buildComponents(
//     graph: dia.Graph<dia.Graph.Attributes, dia.ModelSetOptions>
//   ) {

    
// // // Create all controls and add them to the graph
// // this.addControls(this.paper);

//     const tank1 = new LiquidTank({
//       position: { x: 50, y: 250 },
//       size: { width : 50, height: 100 },
//       attrs: {
//         label: {
//           text: 'Tank',
//         }
//       }
//     });

//     const twoWayValve = new TwoWayValve({
//       position: { x: 50, y: 50 },
//       size: { width : 50, height: 55 },
//       open: 1,
//       attrs: {
//         label: {
//           text: '2-WayValve',
//         }
//       }
//     });

//     const threeWayValve = new ThreeWayValve({
//       position: { x: 50, y: 50 },
//       size: { width : 50, height: 55 },
//       open: 1,
//       attrs: {
//         label: {
//           text: '3-WayValve',
//         }
//       }
//     });


//     const zone1 = new Zone({
//       position: { x: 50, y: 600 },
//       attrs: {
//         label: {
//           text: 'Zone',
//         },
//       },
//     });


// // CTRL Valves

// const controlValve1 = new ControlValve({
// position: { x: 350, y: 250 },
// size: { width : 50, height: 50 },
// open: 1,
// attrs: {
//   label: {
//     text: "CTRL Valve"
//   }
// }
// });


// const handValve2 = new HandValve({
// position: { x: 650, y: 250 },
// size: { width : 50, height: 50 },
// open: 1,
// angle: 0,
// attrs: {
//   label: {
//     text: "Valve"
//   }
// }
// });

// const checkValve = new CheckValve({
//   position: { x: 650, y: 250 },
//   size: { width : 40, height: 90 },
//   open: 1,
//   angle: 0,
//   attrs: {
//     label: {
//       text: "CheckValve"
//     }
//   }
//   });

// const shapesJSON = [
// handValve2.clone(), controlValve1.clone(), tank1.clone(), twoWayValve.clone(), threeWayValve.clone(), checkValve.clone(), zone1.clone()
// ]


// this.stencilSide.load({
//   [StencilGroup.SymbolShapes]: [...shapesJSON]
// });

// }


// private ConnectByPipe(element: dia.Element) {

// if(this.connectList.length == 0)  this.connectList.push(element); 

// //  console.log(element);

// var sourceEle = this.connectList.find(item => item.id != element.id) as dia.Element;

// this.connectList = [];
// this.connectList.push(element); 

// //console.log(this.graph.getCells()[0].attributes["type"]);

//  if(sourceEle != null){

//   var pipeList = this.graph.getCells().filter(item => item.attributes["type"] == "Pipe"
//     && item.attributes["source"].id == sourceEle.id && item.attributes["target"].id == element.id
//   );

// //    console.log(pipeList)
//   if (pipeList != null && pipeList[0] == null) {


//     //console.log(sourceEle);

//     var sourcePosition = sourceEle.attributes["position"] as dia.Cell.Attributes;
//     var targetPosition = element.attributes["position"] as dia.Cell.Attributes;

// const pipe = new Pipe({
//   source: {
//     id: sourceEle.id,
//     port: 'right',
//     anchor: { name: 'left', args: { rotate: true, dx: -38, dy: 14 } },
//     //anchor: { name: 'right', args: { rotate: true, dy: sourcePosition.y - 215 } },
//     //anchor: { name: 'left', args: { dy: -((sourceEle.size().height / 2) - 75), dx: sourceEle.size().width - 25} },
//     //anchor: { name: 'left', args: { dy: -((sourceEle.size().height / 2) - 52) } },
//     connectionPoint: { name: 'anchor' },
//   },
//   target: {
//     id: element.id,
//     port: 'left',
//     anchor: { name: 'bottomLeft', args: { dx: 47, dy: (element.size().height / 2) - 15} },
//     //anchor: { name: 'left', args: { dy: targetPosition.y - 374 } },
//     //anchor: { name: 'bottomLeft', args: { dy: -((element.size().height / 2) + 15), dx: element.size().width - 25} },
//     //anchor: { name: 'bottomLeft', args: { dy: -((element.size().height / 2) + 15)} },
//     connectionPoint: { name: 'anchor' },
//   },
// });

// pipe.addTo(this.graph);
// this.connectList = [];
// this.paper.removeTools();

// const tank1Level= 100;
// const tank1Pipe1Flow = tank1Level > 70 ? 1 : 0;
// const twoWayValveLevel= 100;
// const twoWayValvePipe1Flow = twoWayValveLevel > 70 ? 1 : 0;
// const ctrlValve1Open = sourceEle.get("open");
// const ctrlValve1Pipe1Flow = tank1Pipe1Flow * ctrlValve1Open * twoWayValvePipe1Flow;
// pipe.set("FLOW", 1);


// //this.elementPipeList.push({ sourceEle, element, pipe}); 
// }

// }
// // else{
// //   this.connectList.push(element);
// // }

// // if(this.connectList.length == 2){
// //   //this.connectList.splice(0, this.connectList.length);
// //   this.connectList = [];
// //   //this.connectList.push(element);
// // }

// }

// private GetGraphElements(type: string){

// // var models = this.graph.attributes?.cells?.models;
// // if(models != null)
// //   return models.filter(item => item.attributes["type"] == type)
// // else return [];
// return this.graph.getCells().filter(item => item.attributes["type"] == type);
// }

// private buildLayoutLeft(
// graph: dia.Graph<dia.Graph.Attributes, dia.ModelSetOptions>
// ) {
// const paper = this.paperLeft = new dia.Paper({
//   model: graph,
//   background: {
//     color: '#F8F9FA',
//   },
//   frozen: true,
//   async: true,
//   sorting: dia.Paper.sorting.APPROX,
//   cellViewNamespace: shapes,
// });

// const stencilSide = (this.stencilSide = new ui.Stencil({
//   paper,
//   usePaperGrid: true,
//   width: 100,
//   height: 100,
//   dropAnimation: true,
//   paperOptions: () => {
//     return {
//       model: new dia.Graph({}, { cellNamespace: this.namespace }),
//       cellViewNamespace: shapes,
//       background: {
//         color: "#FFFFFF"
//       },
//       overflow: true
//     };
//   },
//   // search: (cell, keyword) => {
//   //   if (keyword === "") return true;
//   //   if (Placeholder.isPlaceholder(cell)) {

//   //     if (cell === usedShapesPlaceholder) return false;
//   //     return true;
//   //   }
//   //   const keywords = cell.get("keywords") || [];
//   //   return keywords.some(
//   //     (kw: any) => kw.toLowerCase().indexOf(keyword.toLowerCase()) >= 0
//   //   );
//   // },
//   dragStartClone: (cell) => {
//     const dragClone = cell.clone();
//     dragClone.attr(["body", "fill"], "#dde6ed");
//     // Make sure the clone know which group it originally belongs to.
//     // We will use this information in the `element:drag` event handler
//     // to determine whether the element could be saved to the "favorite" group
//     dragClone.set("group", cell.graph.get("group"));
//     return dragClone;
//   },
//   contentOptions: {
//     useModelGeometry: true
//   },
//   canDrag: (elementView) => {
//     return !Placeholder.isPlaceholder(elementView.model);
//   },
//   layout: (graph, group) => {
//     const groupElements = graph.getElements();
//     const layoutElements = graph
//       .getElements()
//       .filter((element) => !Placeholder.isPlaceholder(element));
//     const rowGap = 5;
//     const layoutOptions: any = {
//       columns: 2,
//       rowHeight: 130,
//       columnWidth: 120,
//       horizontalAlign: "middle",
//       rowGap,
//       marginY: rowGap,
//       marginX: rowGap
//     };
//     // // If there was a placeholder element in the group make space for it
//     // if (groupElements.length !== layoutElements.length) {
//     //   const { height: placeholderHeight } = favoriteShapesPlaceholder.size();
//     //   layoutOptions.marginY = placeholderHeight + 2 * rowGap;
//     // }
//     layout.GridLayout.layout(layoutElements, layoutOptions);
//   },
//   groups: {
//     // [StencilGroup.UsedShapes]: {
//     //   index: 1,
//     //   label: "Instrument In Use"
//     // },
//     // [StencilGroup.FavoriteShapes]: {
//     //   index: 2,
//     //   label: "Instrument Shapes"
//     // },
//     [StencilGroup.SymbolShapes]: {
//       index: 1,
//       label: "Instrument",
//       height: 550
//     }
//   }
// }));

// stencilSide.render();

// }

//   private buildLayout(
//     graph: dia.Graph<dia.Graph.Attributes, dia.ModelSetOptions>
//   ) {
//     const paper = this.paper = new dia.Paper({
//       model: graph,
//       background: {
//         color: '#F8F9FA',
//       },
//       frozen: true,
//       async: true,
//       sorting: dia.Paper.sorting.APPROX,
//       cellViewNamespace: this.namespace,
//     });

//     const scroller = (this.scroller = new ui.PaperScroller({
//       paper,
//       autoResizePaper: true,
//       cursor: 'grab'
//     }));

//     scroller.render();
//   }

public ngAfterViewInit(): void {
}
//     const { scroller, paper, paperLeft, canvas, stencil } = this;
//     canvas.nativeElement.appendChild(this.scroller.el);
//     //scroller.center();
//     paper.unfreeze();
//     paperLeft.unfreeze();

//     stencil.nativeElement.appendChild(this.stencilSide.el);
//   }

//   public ngDestroy(): void {
//     this.paper.remove();
//     this.paperLeft.remove();
// };
}
