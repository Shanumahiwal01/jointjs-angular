import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LiquidTankComponent } from './components/liquid-tank/liquid-tank.component';
import { TwoWayValveComponent } from './components/two-way-valve/two-way-valve.component';
import { ThreeWayValveComponent } from './components/three-way-valve/three-way-valve.component';
import { FlowSensorComponent } from './components/flow-sensor/flow-sensor.component';
import { PressureSensorComponent } from './components/pressure-sensor/pressure-sensor.component';
import { ZoneComponent } from './components/zone/zone.component';
import { PipeComponent } from './components/pipe/pipe.component';
import { HandValveComponent } from './components/hand-valve/hand-valve.component';
import { CheckValveComponent } from './components/check-valve/check-valve.component';
import { ControlValveComponent } from './components/control-valve/control-valve.component';
import { PlaceHolderComponent } from './components/place-holder/place-holder.component';
import { ToggleValveControlComponent } from './components/toggle-valve-control/toggle-valve-control.component';
import { SliderValveControlComponent } from './components/slider-valve-control/slider-valve-control.component';
import { ToggleTwoValveControlComponent } from './components/toggle-two-valve-control/toggle-two-valve-control.component';
import { ToggleThreeValveControlComponent } from './components/toggle-three-valve-control/toggle-three-valve-control.component';
import { ControlValveViewComponent } from './components/control-valve-view/control-valve-view.component';
import { PipeViewComponent } from './components/pipe-view/pipe-view.component';
import { ScadaDesignPageComponent } from './containers/scada-design-page/scada-design-page.component';
import { RouterModule } from '@angular/router';
import { LoginPageComponent } from './containers/login-page/login-page.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderViewComponent } from './components/header-view/header-view.component';
import { FooterViewComponent } from './components/footer-view/footer-view.component';

@NgModule({
  declarations: [
    AppComponent,
    LiquidTankComponent,
    TwoWayValveComponent,
    ThreeWayValveComponent,
    FlowSensorComponent,
    PressureSensorComponent,
    ZoneComponent,
    PipeComponent,
    HandValveComponent,
    CheckValveComponent,
    ControlValveComponent,
    PlaceHolderComponent,
    ControlValveViewComponent,
    PipeViewComponent,
    ToggleValveControlComponent,
    SliderValveControlComponent,
    ToggleTwoValveControlComponent,
    ToggleThreeValveControlComponent,
    ScadaDesignPageComponent,
    LoginPageComponent,
    HeaderViewComponent,
    FooterViewComponent
  ],
  imports: [
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule.forChild([
      {
        path: '',
        component: LoginPageComponent,
        pathMatch: 'full'
      },
      {
        path: 'login',
        component: LoginPageComponent,
        pathMatch: 'full'
      },
      {
        path: 'editor',
        component: ScadaDesignPageComponent,
        pathMatch: 'full'
      },
      {
        path: 'logout',
        component: LoginPageComponent,
        pathMatch: 'full'
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
