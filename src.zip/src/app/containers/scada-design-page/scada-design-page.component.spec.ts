import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScadaDesignPageComponent } from './scada-design-page.component';

describe('ScadaDesignPageComponent', () => {
  let component: ScadaDesignPageComponent;
  let fixture: ComponentFixture<ScadaDesignPageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ScadaDesignPageComponent]
    });
    fixture = TestBed.createComponent(ScadaDesignPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
