import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  //userName: string = '';
  loginForm: FormGroup = <FormGroup>{}
  @ViewChild('form', { static: true }) formatElement: NgForm = <NgForm>{};

  constructor(
    private fb: FormBuilder,
  private route: ActivatedRoute,
  private router: Router 
  ){
   // localStorage.setItem('userName', '');
    //this.userName = localStorage.getItem('userName') as string;
  }
  ngOnInit(): void {

    localStorage.setItem('userName', '');
    this.loginForm = this.fb.group({
      userName: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    })
  }

  login(event: any){
    if(this.loginForm.valid)
    {
      console.log(this.loginForm.get('userName')?.value);
      localStorage.setItem('userName', this.loginForm.get('userName')?.value);
      this.router.navigate(['editor']);
    }
      
  }

}
