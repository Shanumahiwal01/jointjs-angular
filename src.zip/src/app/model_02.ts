import { dia, ui, shapes, util } from '@joint/plus';

const LIQUID_COLOR = '#0EAD69';
const LIQUID_COLOR_OFF = '#FF0000';
const TWOWAY_VALVE_VERTICAL= 'M 25 24 L 5 45 L 45 45 Z M 25 23 L 5 5 L 45 5 Z';
const TWOWAY_VALVE_HORIZONTAL = 'M 45 45 L 33 33 L 33 58 Z M 58 58 L 58 33 L 45 45 Z';

// Custom view flags
const POWER_FLAG = "POWER";
const LIGHT_FLAG = "LIGHT";
const FLOW_FLAG = "FLOW";
const OPEN_FLAG = "OPEN";


const StencilGroup = {
  UsedShapes: "used-shapes",
  FavoriteShapes: "favorite-shapes",
  SymbolShapes: "symbol-shapes"
};

class LiquidTank extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'LiquidTank',
      size: {
        width: 160,
        height: 300,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        legs: {
          fill: 'none',
          stroke: '#350100',
          strokeWidth: 8,
          strokeLinecap: 'round',
          d: 'M 20 calc(h) l -5 10 M calc(w - 20) calc(h) l 5 10',
        },
        body: {
          stroke: 'gray',
          strokeWidth: 4,
          x: 0,
          y: 0,
          width: 'calc(w)',
          height: 'calc(h)',
          rx: 120,
          ry: 10,
          fill: {
            type: 'linearGradient',
            stops: [
              { offset: '0%', color: 'gray' },
              { offset: '30%', color: 'white' },
              { offset: '70%', color: 'white' },
              { offset: '100%', color: 'gray' },
            ],
          },
        },
        top: {
          x: 0,
          y: 20,
          width: 'calc(w)',
          height: 20,
          fill: 'none',
          stroke: 'gray',
          strokeWidth: 2,
        },
        label: {
          text: 'Tank',
          textAnchor: 'middle',
          textVerticalAnchor: 'top',
          x: 'calc(w / 2)',
          y: 'calc(h + 20)',
          fontSize: 14,
          fontFamily: 'sans-serif',
          fill: '#350100',
        },
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="legs"/>
            <rect @selector="body"/>
            <rect @selector="top"/>
            <text @selector="label" />
        `;
  }

  get level() {
    return this.get('level') || 0;
  }

  set level(level) {
    const newLevel = Math.max(0, Math.min(100, level));
    this.set('level', newLevel);
  }
}


class Zone extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'Zone',
      size: {
        width: 120,
        height: 40,
      },
      attrs: {
        body: {
          fill: '#ffffff',
          stroke: '#cad8e3',
          strokeWidth: 1,
          d: 'M 0 calc(0.5*h) calc(0.5*h) 0 H calc(w) V calc(h) H calc(0.5*h) Z',
        },
        label: {
          fontSize: 14,
          fontFamily: 'sans-serif',
          fontWeight: 'bold',
          fill: LIQUID_COLOR,
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          x: 'calc(w / 2 + 10)',
          y: 'calc(h / 2)',
        },
      },
       ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="body"/>
            <text @selector="label"/>
        `;
  }
}

class HandValve extends dia.Element {
  defaults(): any{
    return {
      ...super.defaults,
      type: "HandValve",
      size: {
        width: 50,
        height: 50
      },
      power: 0,
      attrs: {
        root: {
          magnetSelector: "body"
        },
        body: {
          rx: "calc(w / 2)",
          ry: "calc(h / 2)",
          cx: "calc(w / 2)",
          cy: "calc(h / 2)",
          stroke: "gray",
          strokeWidth: 2,
          fill: {
            type: "radialGradient",
            stops: [
              { offset: "70%", color: "white" },
              { offset: "100%", color: "gray" }
            ]
          }
        },
        stem: {
          width: 10,
          height: 30,
          x: "calc(w / 2 - 5)",
          y: -30,
          stroke: "#333",
          strokeWidth: 2,
          fill: "#555"
        },
        handwheel: {
          width: 60,
          height: 10,
          x: "calc(w / 2 - 30)",
          y: -30,
          stroke: "#333",
          strokeWidth: 2,
          rx: 5,
          ry: 5,
          fill: "#666"
        },
        label: {
          text: "Valve",
          textAnchor: "middle",
          textVerticalAnchor: "top",
          x: "calc(0.5*w)",
          y: "calc(h+10)",
          fontSize: "14",
          fontFamily: "sans-serif",
          fill: "#350100"
        }
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
                          <rect @selector="pipeBody" />
                          <rect @selector="pipeEnd" />
                      `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },
              pipeBody: {
                width: "calc(w)",
                height: "calc(h)",
                y: "calc(h / -2)",
                fill: {
                  type: "linearGradient",
                  stops: [
                    { offset: "0%", color: "gray" },
                    { offset: "30%", color: "white" },
                    { offset: "70%", color: "white" },
                    { offset: "100%", color: "gray" }
                  ],
                  attrs: {
                    x1: "0%",
                    y1: "0%",
                    x2: "0%",
                    y2: "100%"
                  }
                }
              },
              pipeEnd: {
                width: 10,
                height: "calc(h+6)",
                y: "calc(h / -2 - 3)",
                stroke: "gray",
                strokeWidth: 3,
                fill: "white"
              }
            }
          }
        },
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
          <rect @selector="stem" />
          <rect @selector="handwheel" />
          <ellipse @selector="body" />
          <text @selector="label" />
      `;
  }
}


class Pipe extends dia.Link {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'Pipe',
      z: -1,
      router: { name: 'rightAngle' },
      flow: 1,
      attrs: {
        liquid: {
          connection: true,
          stroke: LIQUID_COLOR,
          strokeWidth: .5,
          strokeLinejoin: 'round',
          strokeLinecap: 'square',
          strokeDasharray: '.1,.2',
        },
        line: {
          connection: true,
          stroke: LIQUID_COLOR, //'#eee',
          strokeWidth: 1,
          strokeLinejoin: 'round',
          strokeLinecap: 'round',
        },
        outline: {
          connection: true,
          stroke: '#444',
          strokeWidth: .16,
          strokeLinejoin: 'round',
          strokeLinecap: 'round',
        },
      },
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="outline" fill="none"/>
            <path @selector="line" fill="none"/>
            <path @selector="liquid" fill="none"/>
        `;

//        console.log(this.markup);
  }
}

class TwoWayValve extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'Triangle',
      size: {
        width: 5,
        height: 5,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        legs: {
          fill: 'lightblue',
          stroke: 'lightblue',
          strokeWidth: 2,
          strokeLinecap: 'butt',
          d: 'M 25 24 L 5 45 L 45 45 Z M 25 23 L 5 5 L 45 5 Z', 
          //d: 'M 45 45 L 33 33 L 33 58 Z M 58 58 L 58 33 L 45 45 Z'
        },
        body: {
          fill: '#ffffff',
          stroke: '#cad8e3',
          strokeWidth: 1,
          d: 'M 0 calc(0.5*h) calc(0.5*h) 0 H calc(w) V calc(h) H calc(0.5*h) Z',
        },
        // top: {
        //   x: 2,
        //   y: 25,
        //   width: 'calc(w)',
        //   height: 1,
        //   fill: 'none',
        //   stroke: 'gray',
        //   strokeWidth: 1,
        // },
        label: {
          text: 'TwoWayValve',
          fontSize: 14,
          fontFamily: 'sans-serif',
          //fontWeight: 'bold',
          fill: "cad8e3",
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          x: 'calc(w / 2)',
          y: 'calc(h / 1)',
        },
      },
      events: {
        "click button": "onButtonClick"
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="legs"/>
            <rect @selector="body"/>
            <rect @selector="top"/>
            <text @selector="label" />
        `;
    // Adding click event listener for rotation
    this.on('element:click', this.rotate);
  }
  get rotation() {
    return this.get('rotation') || 0;
  }
  set rotation(angle: number) {
    this.set('rotation', angle);
    //this.updateRotation();
  }

  get level() {
    return this.get('level') || 0;
  }

  set level(level) {
    const newLevel = Math.max(0, Math.min(100, level));
    this.set('level', newLevel);
  }
}


class ThreeWayValve extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: 'TriTriangle',
      size: {
        width: 5,
        height: 5,
      },
      attrs: {
        root: {
          magnetSelector: 'body',
        },
        legs: {
          fill: 'lightblue',
          stroke: 'lightblue',
          strokeWidth: 2,
          strokeLinecap: 'butt',
          d: 'M 62 75 L 75 100 L 50 100 L 62 75 Z M 87 87 L 87 62 L 87 62 L 62 75 Z M 62 75 L 30 100 L 30 50 L 62 75 Z', 
          //d: 'M 25 24 L 5 45 L 45 45 Z M 25 23 L 5 5 L 45 5 Z', 
        },
        body: {
          fill: '#ffffff',
          stroke: '#cad8e3',
          strokeWidth: 1,
          d: 'M 0 calc(0.5*h) calc(0.5*h) 0 H calc(w) V calc(h) H calc(0.5*h) Z',
        },
        // top: {
        //   x: 2,
        //   y: 25,
        //   width: 'calc(w)',
        //   height: 1,
        //   fill: 'none',
        //   stroke: 'gray',
        //   strokeWidth: 1,
        // },
        label: {
          text: 'TwoWayValve',
          fontSize: 14,
          fontFamily: 'sans-serif',
          //fontWeight: 'bold',
          fill: "cad8e3",
          textVerticalAnchor: 'middle',
          textAnchor: 'middle',
          x: 'calc(w / 2)',
          y: 'calc(h / 1)',
        },
      },
      events: {
        "click button": "onButtonClick"
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
            <path @selector="legs"/>
            <rect @selector="body"/>
            <rect @selector="top"/>
            <text @selector="label" />
        `;
    // Adding click event listener for rotation
    this.on('element:click', this.rotate);
  }
  get rotation() {
    return this.get('rotation') || 0;
  }
  set rotation(angle: number) {
    this.set('rotation', angle);
    //this.updateRotation();
  }

  get level() {
    return this.get('level') || 0;
  }

  set level(level) {
    const newLevel = Math.max(0, Math.min(100, level));
    this.set('level', newLevel);
  }
}

const ToggleTwoValveControl = dia.HighlighterView.extend({
  UPDATE_ATTRIBUTES: ["open"],
  children: util.svg/* xml */ `
        <foreignObject width="100" height="50">
            <div class="jj-switch" xmlns="http://www.w3.org/1999/xhtml">
                <div @selector="label" class="jj-switch-label" style=""></div>
                <button @selector="buttonOn" class="jj-switch-on">open</button>
                <button @selector="buttonOff" class="jj-switch-off">close</button>
            </div>
        </foreignObject>
    `,
  events: {
    "click button": "onButtonClick"
  },
  highlight: function (cellView: any) {
    this.renderChildren();
    const { model } = cellView;
    const { el, childNodes } = this;
    const size = model.size();
    var isOpen = model.get("open");
//    console.log(isOpen);
    el.setAttribute(
      "transform",
      `translate(${size.width / 2 - 50}, ${size.height + 10})`
    );
    childNodes.buttonOn.disabled = isOpen;
    childNodes.buttonOff.disabled = !isOpen;
    childNodes.label.textContent = model.attr("label/text");
  },
  onButtonClick: function (evt: any) {
    var { model } = this.cellView;
    const isOpen = model.get("open");
    model.collection.models.forEach((e: any) => {
      if(e.attributes["type"] == "Pipe"){
        if(e.attributes["target"].id == model.id){
          e.attr("line").stroke = isOpen ? LIQUID_COLOR_OFF : LIQUID_COLOR;
        }
    }

    //console.log(e.attributes);
    //console.log(e);
    
    if(e.attributes["type"] == "Triangle"){
      if(e.attributes["id"] == model.id){
        e.attr("legs").d = isOpen ? TWOWAY_VALVE_VERTICAL : TWOWAY_VALVE_HORIZONTAL;
        //e.attr("legs").stroke = isOpen ? LIQUID_COLOR_OFF : LIQUID_COLOR;
        console.log(e.attr("legs"));
        //e.attributes["rotate"] = 90
      }
  }

    });

    //const { el, childNodes } = this;

    // const el = model as dia.Element
    // if(isOpen)
    //   el.attributes.attrs?.legs?.d?.replace(TWOWAY_VALVE_HORIZONTAL, TWOWAY_VALVE_VERTICAL);
    // else
    //   el.attributes.attrs?.legs?.d?.replace(TWOWAY_VALVE_VERTICAL, TWOWAY_VALVE_HORIZONTAL);

    // console.log(el.attributes.attrs?.legs?.d);
    
    //  (isOpen ?
    //    {
    //     fill: 'lightblue',
    //     stroke: 'lightblue',
    //     strokeWidth: 2,
    //     strokeLinecap: 'butt',
    //     d: TWOWAY_VALVE_VERTICAL
    //   }
    //    : {
    //     fill: 'lightblue',
    //     stroke: 'lightblue',
    //     strokeWidth: 2,
    //     strokeLinecap: 'butt',
    //     d: TWOWAY_VALVE_HORIZONTAL
    //   }));

    model.set("open", !isOpen);
    alert("Id: " + model.id + "; Name: " + model.attr("label/text") + "; New Status: " + (isOpen ? "Close" : "Open") )
  }
});


class CheckValve extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: "CheckValve",
      size: {
        width: 100, // Adjust width and height as per the new SVG dimensions
        height: 100
      },
      attrs: {
        root: {
          magnetSelector: "body"
        },
        body: {
          // Attributes for the polygon and circle
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        polygon: {
          points: "40,30 -1,55 40,85",
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        circle: {
          cx: 26,
          cy: 57,
          r: 13,
          stroke: "purple",
          strokeWidth: 2,
          fill: "white"
        },
        label: {
          text: "CheckValve",
          textAnchor: "middle",
          textVerticalAnchor: "bottom",
          x: "30",
          y: "calc(h + 12)",
          fontSize: "14",
          fontFamily: "sans-serif",
          fill: "#350100"
        }
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
              <rect @selector="pipeBody" />
              <rect @selector="pipeEnd" />
            `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },

              pipeBody: {
                width: "0",
                height: "0",
                y: "calc(h / -2)",
                // fill: {
                //   type: "linearGradient",
                //   stops: [
                //     { offset: "0%", color: "gray" },
                //     { offset: "30%", color: "white" },
                //     { offset: "70%", color: "white" },
                //     { offset: "100%", color: "gray" }
                //   ],
                //   attrs: {
                //     x1: "0%",
                //     y1: "0%",
                //     x2: "0%",
                //     y2: "100%"
                //   }
                // }
              },
              pipeEnd: {
                width: 0,
                height: "0",
                y: "calc(h / -2 - 3)",
                // stroke: "gray",
                // strokeWidth: 3,
                // fill: "white"
              }
            }
          }
        },
        
        
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
      <polygon @selector="polygon" points="40,30 -1,55 40,85" fill="white" stroke="purple" stroke-width="2" />
      <circle @selector="circle" cx="25" cy="55" r="13" fill="white" stroke="purple" stroke-width="2" />
      <text @selector="label" />
    `;
  }
}


class ControlValve extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: "ControlValve",
      size: {
        width: 60,
        height: 60
      },
      open: 1,
      attrs: {
        root: {
          magnetSelector: "body"
        },
        body: {
          rx: "calc(w / 2)",
          ry: "calc(h / 2)",
          cx: "calc(w / 2)",
          cy: "calc(h / 2)",
          stroke: "gray",
          strokeWidth: 2,
          fill: {
            type: "radialGradient",
            stops: [
              { offset: "80%", color: "white" },
              { offset: "100%", color: "gray" }
            ]
          }
        },
        liquid: {
          // We use path instead of rect to make it possible to animate
          // the stroke-dasharray to show the liquid flow.
          d: "M calc(w / 2 + 12) calc(h / 2) h -24",
          stroke: LIQUID_COLOR,
          strokeWidth: 24,
          strokeDasharray: "3,1"
        },
        cover: {
          x: "calc(w / 2 - 12)",
          y: "calc(h / 2 - 12)",
          width: 24,
          height: 24,
          stroke: "#333",
          strokeWidth: 2,
          fill: "#fff"
        },
        coverFrame: {
          x: "calc(w / 2 - 15)",
          y: "calc(h / 2 - 15)",
          width: 30,
          height: 30,
          stroke: "#777",
          strokeWidth: 2,
          fill: "none",
          rx: 1,
          ry: 1
        },
        stem: {
          width: 10,
          height: 30,
          x: "calc(w / 2 - 5)",
          y: -30,
          stroke: "#333",
          strokeWidth: 2,
          fill: "#555"
        },
        control: {
          d: "M 0 0 C 0 -30 60 -30 60 0 Z",
          transform: "translate(calc(w / 2 - 30), -20)",
          stroke: "#333",
          strokeWidth: 2,
          rx: 5,
          ry: 5,
          fill: "#666"
        },
        label: {
          text: "Valve",
          textAnchor: "middle",
          textVerticalAnchor: "top",
          x: "calc(0.5*w)",
          y: "calc(h+10)",
          fontSize: 14,
          fontFamily: "sans-serif",
          fill: "#350100"
        }
      },
      ports: {
        groups: {
          pipes: {
            position: {
              name: "absolute",
              args: {
                x: "calc(w / 2)",
                y: "calc(h / 2)"
              }
            },
            markup: util.svg`
                          <rect @selector="pipeBody" />
                          <rect @selector="pipeEnd" />
                      `,
            size: { width: 50, height: 30 },
            attrs: {
              portRoot: {
                magnetSelector: "pipeEnd"
              },
              pipeBody: {
                width: "calc(w)",
                height: "calc(h)",
                y: "calc(h / -2)",
                fill: {
                  type: "linearGradient",
                  stops: [
                    { offset: "0%", color: "gray" },
                    { offset: "30%", color: "white" },
                    { offset: "70%", color: "white" },
                    { offset: "100%", color: "gray" }
                  ],
                  attrs: {
                    x1: "0%",
                    y1: "0%",
                    x2: "0%",
                    y2: "100%"
                  }
                }
              },
              pipeEnd: {
                width: 10,
                height: "calc(h+6)",
                y: "calc(h / -2 - 3)",
                stroke: "gray",
                strokeWidth: 3,
                fill: "white"
              }
            }
          }
        },
        items: [
          {
            id: "left",
            group: "pipes",
            z: 0,
            attrs: {
              pipeBody: {
                x: "calc(-1 * w)"
              },
              pipeEnd: {
                x: "calc(-1 * w)"
              }
            }
          },
          {
            id: "right",
            group: "pipes",
            z: 0,
            attrs: {
              pipeEnd: {
                x: "calc(w - 10)"
              }
            }
          }
        ]
      }
    };
  }

  preinitialize() {
    this.markup = util.svg/* xml */ `
          <rect @selector="stem" />
          <path @selector="control" />
          <ellipse @selector="body" />
          <rect @selector="coverFrame" />
          <path @selector="liquid" />
          <rect @selector="cover" />
          <text @selector="label" />
      `;
  }
}


class Placeholder extends dia.Element {
  defaults(): any {
    return {
      ...super.defaults,
      type: "Placeholder",
      position: { x: 10, y: 10 },
      attrs: {
        root: {
          style: "cursor:default"
        },
        body: {
          class: "jj-placeholder-body",
          fill: "transparent",
          x: 0,
          y: 0,
          width: "calc(w)",
          height: "calc(h)"
        },
        label: {
          class: "jj-placeholder-label",
          fontSize: 14,
          fontFamily: "sans-serif",
          textVerticalAnchor: "middle",
          textAnchor: "middle",
          x: "calc(w/2)",
          y: "calc(h/2)"
        }
      }
    };
  }

  static isPlaceholder(element: any) {
    return element.get("type") === "Placeholder";
  }

  preinitialize() {
    this.markup = [
      {
        tagName: "rect",
        selector: "body"
      },
      {
        tagName: "text",
        selector: "label"
      }
    ];
  }
}


const ControlValveView = dia.ElementView.extend({
  presentationAttributes: dia.ElementView.addPresentationAttributes({
    open: [OPEN_FLAG]
  }),

  initFlag: [dia.ElementView.Flags.RENDER, OPEN_FLAG],

  framePadding: 6,

  liquidAnimation: null,

  confirmUpdate : function(...args : any) {
    let flags = dia.ElementView.prototype.confirmUpdate.call(this,1,[...args]);
    //this.animateLiquid();
    if (this.hasFlag(flags, OPEN_FLAG)) {
      this.updateCover();
      flags = this.removeFlag(flags, OPEN_FLAG);
    }
    return flags;
  },

  updateCover: function () {
    const { model } = this;
    const opening = Math.max(0, Math.min(1, model.get("open") || 0));
    const [coverEl] = this.findBySelector("cover");
    const [coverFrameEl] = this.findBySelector("coverFrame");
    const frameWidth =
      Number(coverFrameEl.getAttribute("width")) - this.framePadding;
    const width = Math.round(frameWidth * (1 - opening));
    coverEl.animate(
      {
        width: [`${width}px`]
      },
      {
        fill: "forwards",
        duration: 200
      }
    );
  },

  animateLiquid : function() {
    if (this.liquidAnimation) return;
    console.log(this.findBySelector("liquid"));
    //if(this.findBySelector("liquid").length == 0) return;
    const [liquidEl] = this.findBySelector("liquid") as [SVGAElement];
    console.log([liquidEl])
    this.liquidAnimation = liquidEl.animate(
      {
        // 24 matches the length of the liquid path
        strokeDashoffset: [0, 24]
      },
      {
        fill: "forwards",
        iterations: Infinity,
        duration: 3000
      }
    );
  }
});

// const PipeView = dia.LinkView.extend({
//   presentationAttributes: dia.LinkView.addPresentationAttributes({
//     flow: [FLOW_FLAG]
//   }),

//   initFlag: [dia.LinkView.prototype.initFlag, FLOW_FLAG],

//   flowAnimation: null,

//   confirmUpdate: function(...args: any[]) {
//     let flags = dia.LinkView.prototype.confirmUpdate.call(this, 1, [...args]);
//     console.log(flags);
//     this.updateFlow();
//     if (this.hasFlag(flags, FLOW_FLAG)) {
//       this.updateFlow();
//       flags = this.removeFlag(flags, FLOW_FLAG);
//     }
//     return flags;
//   },

//   getFlowAnimation: function() {
//     let { flowAnimation } = this;
//     if (flowAnimation) return flowAnimation;
//     const [liquidEl] = this.findBySelector("liquid");
//     // stroke-dashoffset = sum(stroke-dasharray) * n;
//     // 90 = 10 + 20 + 10 + 20 + 10 + 20
//     const keyframes = { strokeDashoffset: [90, 0] };
//     flowAnimation = liquidEl.animate(keyframes, {
//       fill: "forwards",
//       duration: 1000,
//       iterations: Infinity
//     });
//     this.flowAnimation = flowAnimation;
//     return flowAnimation;
//   },

//   updateFlow: function() {
//     const { model } = this;
//     const flowRate = model.get("flow") || 0;
//     this.getFlowAnimation().playbackRate = flowRate;
//     const [liquidEl] = this.findBySelector("liquid");
//     liquidEl.style.stroke = flowRate === 0 ? "#ccc" : "";
//   }
// });


const PipeView = dia.LinkView.extend({
  presentationAttributes: dia.LinkView.addPresentationAttributes({
    flow: [FLOW_FLAG]
  }),

  initFlag: [dia.LinkView.prototype.initFlag, FLOW_FLAG],

  flowAnimation: null as Animation | null,

  confirmUpdate: function(...args: any[]): any {
    let flags = dia.LinkView.prototype.confirmUpdate.call(this, 1, [...args]);
    console.log(flags);
    this.updateFlow();
    if (this.hasFlag(flags, FLOW_FLAG)) {
      this.updateFlow();
      flags = this.removeFlag(flags, FLOW_FLAG);
    }
    return flags;
  },

  getFlowAnimation: function(): Animation {
    //  debugger;
    let { flowAnimation } = this;
    if (flowAnimation) return flowAnimation;
    const [liquidEl] = this.findBySelector("liquid") as [SVGElement];
    const keyframes = { strokeDashoffset: [90, 0] };
    flowAnimation = liquidEl.animate(keyframes, {
      fill: "forwards",
      duration: 1000,
      iterations: Infinity
    });
    this.flowAnimation = flowAnimation;
    return flowAnimation;
  },

  updateFlow: function(): void {
    const { model } = this;
    const flowRate = model.get("flow") || 0;
    this.getFlowAnimation().playbackRate = flowRate;
    const [liquidEl] = this.findBySelector("liquid") as [SVGElement];
    liquidEl.style.stroke = flowRate === 0 ? "#ccc" : "";
  }
});


const ToggleValveControl = dia.HighlighterView.extend({
  UPDATE_ATTRIBUTES: ["open"],
  children: util.svg/* xml */ `
        <foreignObject width="100" height="50">
            <div class="jj-switch" xmlns="http://www.w3.org/1999/xhtml">
                <div @selector="label" class="jj-switch-label" style=""></div>
                <button @selector="buttonOn" class="jj-switch-on">open</button>
                <button @selector="buttonOff" class="jj-switch-off">close</button>
            </div>
        </foreignObject>
    `,
  events: {
    "click button": "onButtonClick"
  },
  highlight: function (cellView: any) {
    this.renderChildren();
    const { model } = cellView;
    const { el, childNodes } = this;
    const size = model.size();
    const isOpen = model.get("open");
    el.setAttribute(
      "transform",
      `translate(${size.width / 2 - 50}, ${size.height + 10})`
    );
    childNodes.buttonOn.disabled = !isOpen;
    childNodes.buttonOff.disabled = isOpen;
    childNodes.label.textContent = model.attr("label/text");
  },
  onButtonClick: function (evt: any) {
    const { model } = this.cellView;
    const isOpen = model.get("open");
    model.set("open", !isOpen);
    alert("Id: " + model.id + "; Name: " + model.attr("label/text") + "; New Status: " + (isOpen ? "Close" : "Open") )
  }
});

const SliderValveControl = dia.HighlighterView.extend({
  UPDATE_ATTRIBUTES: ["open"],
  children: util.svg/* xml */ `
        <foreignObject width="100" height="60">
            <div class="jj-slider" xmlns="http://www.w3.org/1999/xhtml">
                <div @selector="label" class="jj-slider-label" style="">Valve 4</div>
                <input @selector="slider" class="jj-slider-input" type="range" min="0" max="100" step="25" style="width:100%;"/>
                <output @selector="value" class="jj-slider-output"></output>
            </div>
        </foreignObject>
    `,
  events: {
    "input input": "onInput"
  },
  highlight: function (cellView: any) {
    const { name = "" } = this.options;
    const { model } = cellView;
    const size = model.size();
    if (!this.childNodes) {
      // Render the slider only once to allow the user to drag it.
      this.renderChildren();
      this.childNodes.slider.value = model.get("open") * 100;
    }
    this.el.setAttribute(
      "transform",
      `translate(${size.width / 2 - 50}, ${size.height + 10})`
    );
    this.childNodes.label.textContent = name;
    this.childNodes.value.textContent = this.getSliderTextValue(
      model.get("open")
    );
  },
  getSliderTextValue: function (value = 0) {
    if (value === 0) {
      return "Closed";
    }
    if (value === 1) {
      return "Open";
    }
    return `${value * 100}% open`;
  },
  onInput: function (evt: any) {
    var stage = Number(evt.target.value) ;
    this.cellView.model.set("open", stage / 100);
    alert("Id: " + this.cellView.model.id + "; Name: " + this.cellView.model.attr("label/text") + "; New Value: " + stage + "%" )
  }
});



export { LiquidTank,TwoWayValve, ThreeWayValve, Zone, Pipe, HandValve,CheckValve, ControlValve, Placeholder, StencilGroup,
   ControlValveView, PipeView, ToggleValveControl, SliderValveControl, ToggleTwoValveControl };
