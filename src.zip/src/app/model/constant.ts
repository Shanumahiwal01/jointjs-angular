export const LIQUID_COLOR = '#0EAD69';
export const LIQUID_COLOR_OFF = 'red';
export const TWOWAY_VALVE_VERTICAL= 'M 25 24 L 5 45 L 45 45 Z M 25 23 L 5 5 L 45 5 Z';
export const TWOWAY_VALVE_HORIZONTAL = 'M 45 45 L 33 33 L 33 58 Z M 58 58 L 58 33 L 45 45 Z';

export const THREEOWAY_VALVE_VERTICAL= 'M 25 24 L 5 45 L 45 45 Z M 25 23 L 5 5 L 45 5 Z';
export const THREEWAY_VALVE_HORIZONTAL = 'M 45 45 L 33 33 L 33 58 Z M 58 58 L 58 33 L 45 45 Z';

// Custom view flags
export const POWER_FLAG = "POWER";
export const LIGHT_FLAG = "LIGHT";
export const FLOW_FLAG = "FLOW";
export const OPEN_FLAG = "OPEN";

export const StencilGroup = {
    UsedShapes: "used-shapes",
    FavoriteShapes: "favorite-shapes",
    SymbolShapes: "symbol-shapes"
  };
  